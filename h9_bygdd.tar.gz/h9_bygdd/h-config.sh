####################################################################################
###
### H9
### https://github.com/h9-dev/spacemesh-miner/releases
###
### Hive integration: Gnl & Gdd
###
####################################################################################

#!/usr/bin/env bash
[[ -e /hive/custom ]] && . /hive/custom/h9_bygdd/h-manifest.conf
[[ -e /hive/miners/custom ]] && . /hive/miners/custom/h9_bygdd/h-manifest.conf

echo ""  > $CUSTOM_CONFIG_FILENAME
echo "extraParams:"  >> $CUSTOM_CONFIG_FILENAME
echo "  disablePlot: false" >> $CUSTOM_CONFIG_FILENAME
echo "  serverPort: 10088"  >> $CUSTOM_CONFIG_FILENAME 


