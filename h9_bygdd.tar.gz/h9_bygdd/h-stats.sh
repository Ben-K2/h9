####################################################################################
###
### H9
### https://github.com/h9-dev/spacemesh-miner/releases
###
### Hive integration: Gnl & Gdd
###
####################################################################################

#!/usr/bin/env bash

#######################
# MAIN script body
#######################

#cd `dirname $0`

. /hive/miners/custom/h9_bygdd/h-manifest.conf                                                                                                                                         
nb_gpu=`cat /var/run/hive/gpu-detect.json | jq -r '.[] | select(.brand=="nvidia" or .brand=="amd") | .busid' | cut -d ':' -f 1 | wc -l`

stats_raw=`cat $CUSTOM_LOG_BASENAME.log | grep -w "DeviceID" | tail -n $nb_gpu` 
#echo "nb_gpu = $nb_gpu"
#echo $CUSTOM_LOG_BASENAME.log
#echo "raw is $stats_raw"

algo="SMH"

        busids=''
        idx=0
        jsonBuffer=''
        hashRates=()
        temps=()
        fans=()
        uptime=()

#       echo "gpu worked is $gpu_worked"

        IFS=$'\n' # default separator for NL
        gpu_busid=(`cat /var/run/hive/gpu-detect.json | jq -r '.[] | select(.brand=="nvidia" or .brand=="amd") | .busid' | cut -d ':' -f 1`)
        gpu_stats=$(< $GPU_STATS_JSON)
        echo $gpu_stats
        readarray -t gpu_stats < <( jq --slurp -r -c '.[]  | .busids, .brand, .temp, .fan | join(" ")' $GPU_STATS_JSON  2>/dev/null)
	cpu0=(${gpu_stats[1]:0:3})
        if [ $cpu0 == "cpu" ]; then
        temps=(${gpu_stats[2]:1})
        fans=(${gpu_stats[3]:1})
        else
        temps=(${gpu_stats[2]})
        fans=(${gpu_stats[3]})
        fi
        echo "gpu_temp is $temps"
        echo "gpu_fan is $fans"        
	idx=0           
        busids=()

        for line in $stats_raw; do


         #  echo "cur line is $line"
            gpu=${gpu_busid[$i]}
	    fan_arr+=(${fans[i]})
            temp_arr+=(${temps[i]})
            busids[idx]=$((16#$gpu))
	    pattern='[+-]?([0-9]*[.])?[0-9]+'

            curMatch=`echo "$line" | egrep  -o  $pattern | head -2 | tail -n 1`

          #      echo "match result $curMatch"
                
            hashRates+=($curMatch)
            idx=$((idx+1))

        done

        resHr=0

        awkBuffer='BEGIN {print 1000*(0'
        for hr in ${hashRates[@]}; do
                awkBuffer+=+$hr
        done
        awkBuffer+=")}"

        #echo "awkBuffer $awkBuffer"
        #khs=`awk $awkBuffer`

        #echo `jq -n --arg hrs "${hashRates[@]}"` '$hrs'

#       echo "resHr is $resHr"
        #echo $busids

        hash_json=`printf '%s\n' "${hashRates[@]}" | jq -cs '.'`
        fan_json=`printf '%s\n' "${fans[@]}"  | jq -cs '.'`
        temp_json=`printf '%s\n' "${temps[@]}"  | jq -cs '.'`

	uptime=$(( `date +%s` - `stat -c %Y $CUSTOM_CONFIG_FILENAME` ))

        #echo "jq --argjson gpus ""`echo ${busids[@]} | jq -cs .`"" --arg algo $algo '{ver: "ByGdd"}'"
        echo "jq --argjson gpus ""`echo ${busids[@]} | jq -cs .`"" --arg algo $algo '{hs_units: ""Mhs"", ver: ""ByGdd""}'"
        #stats=$(jq --argjson gpus "`echo ${busids[@]} | jq -cs .`" --arg algo $algo '{hs_units: "Mhs", ver: "ByGdd"}')
        stats=$(jq -nc \
        --argjson hs "$hash_json" \
        --arg ver "$CUSTOM_VERSION" \
	--arg uptime "$uptime" \
	--argjson fan "$fan_json" \
        --argjson temp "$temp_json" \
        '{hs: $hs, hs_units: "Mhs", ver: "1.7.1", algo: "cpupower", $uptime, $fan, $temp}')

	#'{ver: "ByGdd", hs: [.devices[].hashRate / 1000], hs_units: "Khs", temp: [.devices[].temperature], fan: [.devices[].fanPercent], uptime: .uptime, ar: [.validShares, .invalid>

       # khs= #${hashRates[@]}
        khs=`awk $awkBuffer`